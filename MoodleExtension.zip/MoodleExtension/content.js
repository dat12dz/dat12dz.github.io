// Get the OpenAI API key from local storage

      // Create a text box and insert it into the current web page
      const textBox = document.createElement('textarea');
      const QuickQUeryBtn = document.createElement('button');
      const Reslabel = document.createElement('textarea');
      QuickQUeryBtn.textContent = "Short Answer Query";
      textBox.id = "datdauTxtBox";
    
      Reslabel.textContent = "Result will be show here. Copyright ĐạtĐậu Technologies 2023. All rights reserve. Beta v0.2";
      textBox.style.outline = "none";
      Reslabel.disabled = true;
      Reslabel.style.display = "block";
      Reslabel.style.background = "white";
      Reslabel.style.border = "0";
      Reslabel.clientWidth = 900;
      Reslabel.style.fontSize = 12;
      document.body.appendChild(Reslabel);
      document.body.appendChild(textBox);
      document.body.appendChild(QuickQUeryBtn);
      var isTurnOff = false;
      document.addEventListener("keydown", function(event) {
        if (event.ctrlKey && event.key === "h") {
          isTurnOff = !isTurnOff
          if (isTurnOff)
          {
            textBox.style.display = "none";
            Reslabel.style.display = "none";
          }
          else
          {
            textBox.style.display = "block";
            Reslabel.style.display = "block";
          }
        }
      });
      QuickQUeryBtn.addEventListener("click",function(event){
          textBox.value += ".Show only a,b,c,d,e,f as the anwser there is no need to be detail";
      })
      // Add an event listener to the text box to send its contents to the OpenAI API when the Enter key is pressed
      textBox.addEventListener('keydown', function(event) {
        if (event.key === 'Enter' && !event.shiftKey) {
          // ChatGPTUnofficialApi();
          ChatGPTOfficialApi();
        }
       
      });
      document.addEventListener('keydown',function(event)
        {
          if (event.key === "Enter" && event.ctrlKey)
          {
         //   ChatGPTUnofficialApi();
         ChatGPTOfficialApi();
          }
        }
      );
      function PasteBTn()
      {
        const pasteBtn = document.createElement('button');
        pasteBtn.textContent = 'P';
               // Add the elements to the DOM
      
        document.body.appendChild(pasteBtn);

        // Add event listener to button
        pasteBtn.addEventListener('click', function() {
          navigator.clipboard.readText().then((text) => {
            textBox.value = text;
  });
});

      }
      PasteBTn();
     async function ChatGPTOfficialApi()
      {
        Reslabel.textContent = "Thinking...";
        async function sendToChatGPT(prompt1) {
        
         //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
          const response = await fetch('https://api.openai.com/v1/completions', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': 'Bearer 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' // replace with your API key
            },
            body: JSON.stringify({
              "model": "text-davinci-003",
              "temperature": 0.2,
              prompt: prompt1,
              max_tokens: 2048,
            })
          });
        
          const data = await response.json();
          return data.choices[0].text;
        }
        console.log(textBox.textContent);
          Reslabel.value = await sendToChatGPT(textBox.value);
          Reslabel.value = Reslabel.value.replace('\n','');
      }
      function ChatGPTUnofficialApi()
      {
        Reslabel.textContent = "Thinking...";
        event.preventDefault();
        // Send a request to the OpenAI API to generate text
        const apiEndpoint = "http://localhost:32340";
 
        const prompt1 = textBox.value;
        textBox.value = "";
        
        const requestOptions = {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
           'prompt': prompt1
          })
        };
        
        fetch(apiEndpoint, requestOptions)
          .then(response => response.json())
          .then(data => {  
            try{
              
               console.log(data.ans) ;
               Reslabel.textContent = data.ans;
                          
              }
              catch {
                Reslabel.textContent ='ChatGPT API request failed: ' + data.error.message;
              }
          }                       
           )
          .catch(error => { console.log(error); Reslabel.textContent = error});
      }
    function LinkCss(path)
    {
        var link = document.createElement("link");

        // Set the link's attributes
        link.setAttribute("rel", "stylesheet");
        link.setAttribute("type", "text/css");
        link.setAttribute("href", path);
        
        // Add the link to the document
        document.head.appendChild(link);
    }

  function ChangeElementText()
  {
    var x = event.clientX;
    var y = event.clientY;
    var element = document.elementFromPoint(x, y);
    console.log(element);
  }
  function CopyIntoTextBox()
  {
    
// Select all text elements
const textElements = document.querySelectorAll('p, span, h1, h2, h3, h4, h5, h6, li, td,dt,label');

// Loop through each text element and add a copy button
textElements.forEach(element => {
  // Create a new button element
  if (element.textContent != "" && !(element.innerHTML.includes('<') && element.innerHTML.includes('>')&& 
  element.innerHTML.includes('/')))
  {
  const buttonElement = document.createElement('button');

  // Set the button text and add a click event listener
  buttonElement.textContent = 'C';
  buttonElement.addEventListener('click', () => {
    // Copy the text to the clipboard
    const textToCopy = element.textContent;
    navigator.clipboard.writeText(textToCopy);
    textBox.textContent += textToCopy + '\n';
    // Show a notification to the user that the text has been copied
  
  });

  // Add the button element after the text element
  element.parentNode.insertBefore(buttonElement, element.nextSibling);
}
});


  }
  CopyIntoTextBox();
