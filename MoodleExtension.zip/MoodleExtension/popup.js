const form = document.getElementById('openaiApiKeyForm');
const apiKeyInput = document.getElementById('openaiApiKey');

form.addEventListener('submit', submit2);
function submit2(event) {
  event.preventDefault();

  // Save the OpenAI API key to local storage
  chrome.storage.local.set({ 'openaiApiKey': apiKeyInput.value }, function() {
    console.log('OpenAI API key saved:', apiKeyInput.value);
    window.close();
  });
}
function SendData(dataInp)
{
    document.getElementById('send-data').addEventListener('click', function() {
        chrome.runtime.sendMessage({ data: dataInp });
      });
}